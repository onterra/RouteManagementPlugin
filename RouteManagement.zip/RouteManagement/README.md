# Route Management Plugin

**Author:** OnTerra Systems

Full route dispatch lifecycle — from address geocoding and multi-driver route optimization to Cloudflare-hosted route pages and HTML email dispatch via Gmail.

## Required Connectors

Connect both of the following before using this plugin:

| Connector | Purpose |
|-----------|---------|
| **Route Management (RouteSavvy)** | Geocoding, route optimization, HTML map generation, Cloudflare deployment, email template generation, incident checking, reports |
| **Gmail** | Creating email drafts for driver dispatch |

Both connectors must be active in Cowork for the skills to function.

## Skills

| Skill | Trigger phrases | Description |
|-------|----------------|-------------|
| **route-optimize** | "create a route", "dispatch a route", "optimize stops", "plan deliveries" | Full dispatch: collect inputs → geocode → optimize → generate HTML page → deploy → email HTML via Gmail |
| **geocode** | "geocode an address", "get coordinates for", "find lat/long" | Single or small-batch address → coordinates (up to 4 addresses) |
| **batch-geocode** | "batch geocode", "geocode a list", "geocode from CSV" | Batch address → coordinates for 5+ addresses |
| **reverse-geocode** | "reverse geocode", "address for these coordinates", "what's at this lat/long" | Coordinates → human-readable address |
| **search-poi** | "find nearby places", "search for gas station near", "POIs near" | Search for points of interest near a location |
| **web-display** | "generate route map", "create HTML route page", "driver map" | Generate mobile-friendly Leaflet.js HTML route page per driver |
| **web-display-deploy** | "deploy route page", "publish route", "get a public URL for route" | Deploy HTML route page to Cloudflare Pages |
| **email-template** | "generate route email", "create driver email", "dispatch email" | Generate styled HTML email via Email_template + create Gmail draft |
| **check-incidents** | "check for incidents", "scan routes for exceptions", "tomorrow's route problems" | Scan routes for driver-reported exceptions needing rescheduling |
| **route-reports** | "route report", "stop status report", "get CSV for route" | Collect all stop statuses and produce a CSV report |

## Typical Workflow

```
1. route-optimize   →  Collect inputs, geocode, optimize, generate page, deploy, email
2. check-incidents  →  Next-day review for exceptions
3. route-reports    →  End-of-day status report per route
```

## Key Rules

- **HTML is always MCP-generated**: `web-display` and `web-display-deploy` use `Web_display` and `Web_display_deploy` tools respectively. `email-template` uses `Email_template`. Never substitute manually written HTML.
- **Emails are drafts only**: Gmail drafts are created but never sent automatically. The dispatcher reviews and sends from Gmail.
- **One page per driver**: Route pages and emails are generated per driver, never combined.

## Route Inputs Required

When using `route-optimize`, the following are collected via form before any processing begins:

- Start address (depot/warehouse)
- End address (return location)
- Stop addresses (delivery/visit locations)
- Optimize by: Time or Distance
- Driver availability from (HH:mm)
- Driver availability to (HH:mm)
- Number of drivers
- Driver name + email (one per driver)
