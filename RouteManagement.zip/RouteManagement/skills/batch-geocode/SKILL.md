---
name: batch-geocode
description: >
  This skill should be used when the user wants to "batch geocode addresses",
  "geocode a list of addresses", "convert multiple addresses to coordinates",
  "geocode from a CSV", or "get lat/long for many addresses at once". Use
  when 5 or more addresses need to be geocoded in a single operation.
metadata:
  version: "0.1.0"
---

## Purpose

Geocode 5 or more addresses in a single batch operation using `Batch_geocode`. Faster and more efficient than calling `Geocode` individually for each address.

---

## Steps

1. Accept addresses in any of these formats:
   - **Plain text**: one address per line
   - **JSON array**: array of address objects
   - **CSV file**: uploaded by the user or provided as file path

2. Call `Batch_geocode` with one of:
   - `text_input`: plain multiline text (one address per line)
   - `json_addresses`: array of address objects
   - `csv_file`: CSV content or absolute path to a CSV file

3. Present results as a table showing:
   - Original input address
   - Matched address
   - Latitude
   - Longitude
   - Match confidence/quality (if available)

4. Flag any addresses that failed to geocode or returned low-confidence results so the user can review them.

5. Offer to export results as a CSV if the user needs the coordinates for further use.

---

## Notes

- For fewer than 5 addresses, the `geocode` skill (single lookups) may be faster.
- If addresses come from a CSV with additional columns (e.g., customer names), preserve those columns in the output.
- Addresses that fail to match should be listed separately so the dispatcher can correct them before route optimization.
