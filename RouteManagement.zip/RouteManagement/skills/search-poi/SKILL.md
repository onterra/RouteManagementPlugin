---
name: search-poi
description: >
  This skill should be used when the user wants to "search for nearby places",
  "find a gas station near me", "find POIs near an address", "search for
  restaurants near coordinates", "look up nearby businesses", or "what's
  close to this location". Use for any points-of-interest search around
  a specific geographic location.
metadata:
  version: "0.1.0"
---

## Purpose

Search for Points of Interest (POIs) near a given location using `Search` (HERE Maps API).

---

## Steps

1. Collect the following from the user if not already provided:
   - **Search query**: what to look for (e.g., "gas station", "hospital", "Starbucks")
   - **Center location**: address or coordinates to search around
   - **Radius** (optional): search radius in metres (default 5000 m = 5 km)
   - **Limit** (optional): max results to return (default 10, max 100)

2. If the user provides an address instead of coordinates, call `Geocode` first to convert it to lat/lon.

3. Call `Search`:
   - `query`: the search string
   - `lat`: latitude of the center point
   - `lon`: longitude of the center point
   - `radius`: search radius in metres
   - `limit`: max number of results
   - `language`: default `"en-US"`

4. Present results as a table:

| # | Name | Address | Distance | Category |
|---|------|---------|----------|----------|
| 1 | ... | ... | ... | ... |

5. If the user wants to use one of the results as a stop in a route, offer to add it to a route-optimize session.

---

## Notes

- The search is powered by HERE Maps and covers restaurants, fuel stations, hospitals, retail, and other business categories globally.
- Increasing the radius or limit may return more results but could slow the response.
- For precise POI lookups, a more specific query (e.g., "Shell gas station") returns better results than a generic one ("gas").
