---
name: dispatch
description: >
  This skill should be used for any route management task — "dispatch a route",
  "create a route", "optimize stops", "send route to driver", "geocode an address",
  "batch geocode", "reverse geocode", "find nearby places", "generate route map",
  "deploy route page", "generate route email", "check for incidents", "route report",
  "get CSV for route", or any delivery, driver, or route-related request. This is the
  single entry point for all Route Management capabilities.
metadata:
  version: "0.1.0"
---

## Purpose

Master orchestration skill for all Route Management capabilities. Start here for any route, driver, geocoding, map, email, incident, or report task.

---

## Step 1 — Identify the Task

Use `AskUserQuestion` to ask which workflow the user needs (if not already clear from their message):

| # | Task | When to use |
|---|------|-------------|
| 1 | **Full Route Dispatch** | Plan stops → optimize → generate map → deploy → email drivers |
| 2 | **Geocode Addresses** | Convert 1–4 addresses to coordinates |
| 3 | **Batch Geocode** | Convert 5+ addresses to coordinates at once |
| 4 | **Reverse Geocode** | Convert GPS coordinates to a human-readable address |
| 5 | **Search Nearby Places** | Find POIs (gas stations, restaurants, etc.) near a location |
| 6 | **Generate Route Map** | Create a mobile HTML route page for a driver |
| 7 | **Deploy Route Page** | Publish an HTML route page to Cloudflare and get a public URL |
| 8 | **Generate Route Email** | Create HTML email body + Gmail draft for a driver |
| 9 | **Check Incidents** | Scan routes for exceptions needing rescheduling |
| 10 | **Route Report** | Get a CSV stop-status report for a completed route |

If the user's request clearly maps to one task, skip this question and go directly to that workflow below.

---

## Workflow 1 — Full Route Dispatch

End-to-end: collect inputs → geocode → optimize → HTML page → deploy → email → Gmail draft.

### 1a. Collect Inputs

Gather all of the following in one `AskUserQuestion` form:

| Field | Details |
|-------|---------|
| **Stop addresses** | Delivery addresses — comma-separated, one per line, or CSV |
| **Start address** | Depot / warehouse / starting location |
| **End address** | Where drivers finish (can match start) |
| **Optimize by** | Time (fastest) or Distance (shortest) |
| **Availability from** | Start time HH:mm (e.g., "08:00") |
| **Availability to** | End time HH:mm (e.g., "18:00") |
| **Number of drivers** | Integer 1–10 |
| **Driver names & emails** | One name + email per driver |

### 1b. Geocode Stops

- 1–4 stops → call `Geocode` for each address individually
- 5+ stops → call `Batch_geocode` with all addresses at once
- Also geocode the start and end address

### 1c. Optimize the Route

Call `Route_optimize`:
- `locationsJson`: all geocoded stops (VisitDurationInMinutes = 0 for depot, 15 for stops)
- `vehiclesJson`: one entry per driver with vehicle_id, StartLocation, EndLocation, DriverAvailabilityFrom, DriverAvailabilityTo
- `optimizeType`: "time" or "distance"
- `minimizeVehicles`: false

### 1d. Generate HTML Route Page

For each driver, call `Web_display` with only that driver's stops.
**Never write HTML manually** — use only what `Web_display` returns.
- `jobId`: "ROUTE-YYYYMMDD-DriverName"
- `driverName`: driver's name
- `stopsJson`: that driver's stops array

### 1e. Deploy to Cloudflare

For each driver, call `Web_display_deploy` with the HTML from 1d.
**Never deploy manually written HTML.**
- `htmlContent`: HTML returned by `Web_display`
- `jobId`: same Job ID

Store returned URL as `ROUTE_URL_<DriverName>`.

### 1f. Generate Email HTML

For each driver, call `Email_template`.
**Never write email HTML manually.**
- `driverName`, `date`, `totalStops`, `estDistance`, `estDuration`
- `departure`, `returnTime`, `optimizedBy`, `jobId`
- `stopsJson`: stop array with stopNumber, customer, address, eta, depart
- `cloudflareUrl`: ROUTE_URL from 1e

### 1g. Create Gmail Draft

For each driver, call `gmail__create_draft`:
- `to`: driver's email
- `subject`: "Your Route — DriverName | date"
- `body`: HTML from Email_template
- `mimeType`: "text/html"

Each driver gets their own draft. Never combine into one email. Never auto-send.

### 1h. Confirm to Dispatcher

```
✅ Route optimized — N total stops across X drivers

🚚 Driver 1 — N stops | ~X min | ~Y km | Route: URL | Gmail draft ready
🚚 Driver 2 — N stops | ~X min | ~Y km | Route: URL | Gmail draft ready
```

---

## Workflow 2 — Geocode Addresses (1–4)

Call `Geocode` for each address provided. Return a table:

| Address | Latitude | Longitude |
|---------|----------|-----------|

For 5+ addresses, switch to Workflow 3.

---

## Workflow 3 — Batch Geocode (5+)

Call `Batch_geocode` with all addresses at once. Return a results table with address, lat, lng, and any failed lookups highlighted.

---

## Workflow 4 — Reverse Geocode

Ask for coordinates if not provided. Call `Reverse_geocode`:
- `coordinates`: "lon,lat" (longitude first, then latitude)

Return the human-readable address.

---

## Workflow 5 — Search Nearby Places

Ask for: location (address or coordinates) and what to search for (e.g., "gas stations", "restaurants").

Call `Search` with the location and query. Return a table of results with name, address, and distance.

---

## Workflow 6 — Generate Route Map

Ask for: driver name, Job ID, and the list of stops (address, lat, lng, sequence).

Call `Web_display`:
- `jobId`: unique route ID
- `driverName`: driver's name
- `stopsJson`: stops array

Return the HTML to the user or proceed to Workflow 7 to deploy it.

---

## Workflow 7 — Deploy Route Page

Ask for: the HTML content (from a prior `Web_display` call) and the Job ID.

Call `Web_display_deploy`:
- `htmlContent`: HTML from `Web_display` only — never manually written HTML
- `jobId`: route Job ID

Return the public Cloudflare URL.

---

## Workflow 8 — Generate Route Email + Gmail Draft

Ask for all email_template parameters: driverName, date, totalStops, estDistance, estDuration, departure, returnTime, optimizedBy, jobId, stopsJson, cloudflareUrl.

1. Call `Email_template` — **never write email HTML manually**
2. Call `gmail__create_draft` with the returned HTML, mimeType "text/html"

Confirm: draft created for DriverName at email address.

---

## Workflow 9 — Check Incidents

Ask whether to scan by:
- **Route IDs**: array of route IDs (e.g., ["ROUTE-20260618-Alice"])
- **Date prefix**: date string "YYYY-MM-DD" to scan all routes that day

Call `CheckNextDayIncidents` with `routeIds` or `datePrefix`.

Return a table of routes with incidents, affected stops, exception types, and recommended action (reschedule / reassign / contact driver).

---

## Workflow 10 — Route Report

Ask for the Route/Job ID to report on.

Call `Reports` with `routeId`.

Parse the returned CSV and present:

| Stop # | Customer | Address | Status | Notes |
|--------|----------|---------|--------|-------|

Summarize totals: completed, exceptions, pending. Offer to save as CSV or flag exceptions for follow-up via Workflow 9.

---

## Error Handling

| Error | Action |
|-------|--------|
| `Route_optimize` fails | Report which address failed; ask user to verify |
| `Web_display_deploy` fails | Provide HTML as file fallback |
| `Email_template` fails | Fall back to plain-text email body |
| `gmail__create_draft` fails | Show full email body for manual copy-paste |
| Driver assigned 0 stops | Skip their page and draft; notify dispatcher |
| Geocode returns no match | Report the failing address; ask user to correct it |
