---
name: reverse-geocode
description: >
  This skill should be used when the user wants to "reverse geocode coordinates",
  "find the address for these coordinates", "what address is at this lat/long",
  "convert GPS coordinates to an address", or "look up a location from coordinates".
metadata:
  version: "0.1.0"
---

## Purpose

Convert latitude/longitude coordinates to a human-readable address using `Reverse_geocode`.

---

## Steps

1. Ask the user for the coordinates to reverse geocode if not already provided. Accept:
   - `lon,lat` format (e.g., `-104.98,39.71`)
   - Separate lat and lon values
   - GPS strings like `39.71° N, 104.98° W`

2. Normalize coordinates to `lon,lat` decimal format required by the API.

3. Call `Reverse_geocode`:
   - `coordinates`: `"<lon>,<lat>"` (longitude first)
   - `resultTypes`: optionally filter to `"Address"` for street-level results, or `"Area"` for area/region results

4. Present the result:
   - Full matched address
   - Address components (street, city, state, country, postal code)
   - Coordinates that were queried

5. If no address is found (e.g., coordinates are in a remote area), inform the user and suggest checking the coordinate format.

---

## Notes

- Coordinates must be in WGS84 decimal degrees.
- Longitude comes **first** in the `coordinates` parameter (e.g., `-104.98,39.71` not `39.71,-104.98`).
- `resultTypes` can be `Address`, `Area`, `Intersection`, or a comma-separated combination.
