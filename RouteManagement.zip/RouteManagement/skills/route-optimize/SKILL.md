---
name: route-optimize
description: >
  This skill should be used when the user wants to "create a route", "optimize a route",
  "dispatch a route", "plan deliveries", "assign stops to drivers", "send route to driver",
  "optimize stops", or "plan a delivery run". Use whenever multiple stops, driver
  assignments, and Gmail dispatch are involved in a single workflow.
metadata:
  version: "0.1.0"
---

## Purpose

Full route dispatch lifecycle: collect inputs → geocode → optimize → generate HTML route page → deploy to Cloudflare → generate HTML email via Email_template → send Gmail draft per driver.

---

## Step 1 — Collect Route Inputs

Use `AskUserQuestion` to gather all of the following in a single form. Do not proceed until all answers are provided.

| Field | Details |
|-------|---------|
| **Stop addresses** | Delivery/visit addresses — comma-separated, one per line, or CSV |
| **Start address** | Depot, warehouse, or starting address for all drivers |
| **End address** | Where drivers finish (can be same as start or different) |
| **Optimize by** | **Time** (minimize total travel time) or **Distance** (minimize total km/miles) |
| **Driver availability from** | Start time in HH:mm format (e.g., "08:00") |
| **Driver availability to** | End time in HH:mm format (e.g., "18:00") |
| **Number of drivers** | Integer 1–10 |
| **Driver names & emails** | Name + email for each driver |

---

## Step 2 — Geocode Stops

- For 1–4 stops: call `Geocode` individually for each address.
- For 5+ stops: call `Batch_geocode` with all addresses at once (faster).
- Also geocode the start address and end address to confirm they resolve correctly.

---

## Step 3 — Optimize the Route

Call `Route_optimize` with:
- `locationsJson`: full array of geocoded stops including the depot (VisitDurationInMinutes = 0 for depot, default 15 for stops unless specified)
- `vehiclesJson`: one entry per driver:
  ```json
  {
    "vehicle_id": "<DriverName>",
    "StartLocation": "<start_address>",
    "EndLocation": "<end_address>",
    "DriverAvailabilityFrom": "<HH:mm>",
    "DriverAvailabilityTo": "<HH:mm>"
  }
  ```
- `optimizeType`: `"time"` or `"distance"` per user's choice
- `minimizeVehicles`: `false` (use all drivers provided)

The tool returns stops grouped by vehicle with ETA, departure time, distance, and duration per driver. Store this result — it drives all subsequent steps.

---

## Step 4 — Generate HTML Route Page (MCP-generated)

For each driver, call `Web_display` with only that driver's assigned stops from the optimizer result.

**Do NOT manually write HTML.** `Web_display` returns a complete, mobile-friendly Leaflet.js HTML page. Store the HTML for the next step.

Parameters:
- `jobId`: a unique ID for this route (e.g., `ROUTE-<YYYYMMDD>-<DriverName>`)
- `driverName`: driver's name
- `stopsJson`: JSON array of that driver's stops: `[{stopId, name, address, lat, lng, sequence}]`

---

## Step 5 — Deploy Route Page to Cloudflare

For each driver, call `Web_display_deploy` with their HTML from Step 4.

**Do NOT deploy manually created HTML.** Only pass the HTML returned by `Web_display`.

Parameters:
- `htmlContent`: the HTML string returned by `Web_display`
- `jobId`: same Job ID used in Step 4

Each call returns a public Cloudflare URL. Store as `ROUTE_URL_<DriverName>`.

---

## Step 6 — Generate HTML Email Template (MCP-generated)

For each driver, call `Email_template` to generate the HTML email body.

**Do NOT manually write the email HTML.** Use only the HTML returned by `Email_template`.

Parameters:
- `driverName`: driver's name
- `date`: today's date formatted as "Day, Month DD, YYYY" (e.g., "Thursday, June 18, 2026")
- `totalStops`: number of stops assigned to this driver
- `estDistance`: estimated distance string from optimizer (e.g., "45.2 mi")
- `estDuration`: estimated duration string from optimizer (e.g., "2h 30m")
- `departure`: departure time and location (e.g., "08:00 - Depot")
- `returnTime`: return time and location (e.g., "11:30 - Depot")
- `optimizedBy`: optimization method label (e.g., "Fastest time" or "Shortest distance")
- `jobId`: same Job ID used above
- `stopsJson`: JSON array `[{stopNumber, customer, address, eta, depart}]` for this driver
- `cloudflareUrl`: the `ROUTE_URL_<DriverName>` from Step 5

---

## Step 7 — Create Gmail Draft Per Driver

For each driver, call `gmail__create_draft`:
- `to`: driver's email
- `subject`: `Your Route — <DriverName> | <date>`
- `body`: the HTML string returned by `Email_template` in Step 6
- `mimeType`: `text/html`

Each driver gets their own separate draft. Never combine multiple drivers into one email.

---

## Step 8 — Confirm to Dispatcher

Summarize results after all drafts are created:

```
✅ Route optimized — <N> total stops across <X> drivers

🚚 <Driver 1>  — <N> stops | ~<X> min | ~<Y> km | Route: <URL> | Gmail draft ready
🚚 <Driver 2>  — <N> stops | ~<X> min | ~<Y> km | Route: <URL> | Gmail draft ready
```

Do NOT send emails automatically. The dispatcher must review and send from Gmail.

---

## Error Handling

| Error | Action |
|-------|--------|
| `Route_optimize` fails | Report which address caused the issue; ask dispatcher to verify |
| `Web_display_deploy` fails | Provide the HTML as a file fallback; note the error |
| `Email_template` fails | Fall back to a plain-text email body; note that HTML template unavailable |
| `gmail__create_draft` fails | Display the full email body so dispatcher can copy-paste manually |
| Driver assigned 0 stops | Skip their page and draft; notify dispatcher |
