---
name: check-incidents
description: >
  This skill should be used when the user wants to "check for incidents",
  "scan routes for exceptions", "check tomorrow's routes for problems",
  "find routes that need rescheduling", "check route exceptions", or
  "are there any incidents on my routes". Use to scan one or more routes
  for stops that have reported exceptions and need attention.
metadata:
  version: "0.1.0"
---

## Purpose

Scan routes for exceptions (incidents) that need rescheduling or follow-up using `CheckNextDayIncidents`.

---

## Steps

1. Ask the user how they want to scan:
   - **By route IDs**: specify one or more Route/Job IDs to check
   - **By date**: check all routes for a given date (provide a date prefix like `2026-06-18`)

2. Call `CheckNextDayIncidents` with:
   - `routeIds`: array of Route IDs (e.g., `["ROUTE-20260618-Alice", "ROUTE-20260618-Bob"]`), OR
   - `datePrefix`: a date string `"YYYY-MM-DD"` to scan all routes starting with that date

   Both parameters are optional — provide at least one.

3. Parse the results and present a summary:

| Route ID | Driver | Incidents | Details |
|----------|--------|-----------|---------|
| ... | ... | ... | ... |

4. For each route with incidents:
   - List the affected stops
   - Describe the exception type
   - Suggest action: reschedule, reassign, or contact driver

5. If no incidents are found, confirm all routes are clear.

6. Offer to generate an updated report via the `route-reports` skill if rescheduling is needed.

---

## Notes

- "Incidents" are exceptions reported by drivers (e.g., access denied, customer not home, address not found).
- Check the next day's routes the evening before to catch issues in advance.
- Route IDs follow the pattern used during `route-optimize` (e.g., `ROUTE-YYYYMMDD-DriverName`).
