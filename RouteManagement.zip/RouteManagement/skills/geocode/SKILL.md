---
name: geocode
description: >
  This skill should be used when the user wants to "geocode an address",
  "get coordinates for an address", "convert address to lat/long",
  "find the location of an address", or "look up coordinates". Use for
  single address lookups (1–4 addresses). For 5 or more addresses use
  the batch-geocode skill instead.
metadata:
  version: "0.1.0"
---

## Purpose

Convert one or more addresses (up to 4) to latitude/longitude coordinates using the HERE Maps API via `Geocode`.

---

## Steps

1. Ask the user for the address or addresses to geocode if not already provided. Accept free-text addresses, street addresses, city names, or partial addresses.

2. For each address, call `Geocode`:
   - `query`: the full address string
   - Optionally set `addressLine`, `locality`, `adminDistrict`, `postalCode`, `countryRegion` if the user provides structured components
   - `top`: default 1 (return the best match); increase if the user wants multiple candidates

3. Present results in a clear table:

| Address | Latitude | Longitude | Match Quality |
|---------|----------|-----------|---------------|
| ... | ... | ... | ... |

4. If the result returns multiple candidates, present all and ask the user to confirm the correct one.

5. If no result is found, suggest checking the address for typos or trying a less specific query.

---

## Notes

- For 5+ addresses, recommend switching to the `batch-geocode` skill for efficiency.
- Coordinates are returned in WGS84 (decimal degrees).
- Results may include the matched address text — show this so the user can verify accuracy.
