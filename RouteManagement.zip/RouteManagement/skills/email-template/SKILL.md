---
name: email-template
description: >
  This skill should be used when the user wants to "generate a route email",
  "create an HTML email for a driver", "make an email template for a route",
  "build a dispatch email", "generate email body for route", or "create
  a driver notification email". Use to produce the HTML email body for
  sending route details to a driver via Gmail.
metadata:
  version: "0.1.0"
---

## Purpose

Generate a professionally formatted HTML email for a driver's route using `Email_template`, then create a Gmail draft using `gmail__create_draft`.

**Do NOT manually write the email HTML.** Always call `Email_template` — it returns the complete, styled HTML body. The resulting HTML is passed directly to Gmail.

---

## Step 1 — Collect Email Data

Gather the following (typically available after running `route-optimize`):

| Field | Description | Example |
|-------|-------------|---------|
| `driverName` | Driver's full name | "Alice Johnson" |
| `date` | Route date, formatted | "Thursday, June 18, 2026" |
| `totalStops` | Number of stops assigned | 8 |
| `estDistance` | Estimated total distance | "45.2 mi" |
| `estDuration` | Estimated total duration | "2h 30m" |
| `departure` | Departure time and location | "08:00 - Main Depot" |
| `returnTime` | Return time and location | "11:30 - Main Depot" |
| `optimizedBy` | Optimization label | "Fastest time" or "Shortest distance" |
| `jobId` | Unique route Job ID | "ROUTE-20260618-Alice" |
| `stopsJson` | Stop details array | `[{stopNumber, customer, address, eta, depart}]` |
| `cloudflareUrl` | Public route page URL | "https://..." |

---

## Step 2 — Generate HTML Email

Call `Email_template` with all fields above. The tool returns a complete, styled HTML string.

Store the result as `EMAIL_HTML_<DriverName>`.

---

## Step 3 — Create Gmail Draft

Call `gmail__create_draft`:
- `to`: driver's email address
- `subject`: `"Your Route — <DriverName> | <date>"`
- `body`: the `EMAIL_HTML_<DriverName>` string from Step 2 (pass as-is, do not modify)
- `mimeType`: `"text/html"`

---

## Step 4 — Confirm

Confirm the draft was created:
```
✅ Gmail draft created for <DriverName> (<email>)
   Subject: Your Route — <DriverName> | <date>
   Stops: <N> | Distance: <X> | Duration: <Y>
```

Remind the dispatcher to review and send from Gmail — drafts are never sent automatically.

---

## Notes

- One email per driver — never combine multiple drivers in one email.
- The `stopsJson` format for this tool is `[{stopNumber, customer, address, eta, depart}]` — different from the `Web_display` format. Convert accordingly from the optimizer output.
- `cloudflareUrl` must be a valid deployed URL (from `web-display-deploy`). Do not use a placeholder.
