---
name: web-display
description: >
  This skill should be used when the user wants to "generate a route map",
  "create an HTML route page", "make a mobile route page for a driver",
  "show stops on a map", "generate a driver view", or "create an interactive
  map for a delivery route". Use to produce a shareable HTML page that drivers
  can open on their phone.
metadata:
  version: "0.1.0"
---

## Purpose

Generate a mobile-friendly interactive HTML route page per driver using `Web_display`. The page includes a Leaflet.js map with stop markers and an action-ready stop list.

**Do NOT manually write HTML for the route page.** Always use `Web_display` — it returns the complete, production-ready HTML.

---

## Steps

1. Collect the following if not already available (e.g., from a prior `route-optimize` run):
   - **Job ID**: unique identifier for this route (e.g., `ROUTE-20260618-Alice`)
   - **Driver name**: the driver this page is for
   - **Stops**: ordered list of stops with: stopId, name, address, lat, lng, sequence

2. Format `stopsJson` as a JSON array:
   ```json
   [
     { "stopId": "S1", "name": "Customer A", "address": "123 Main St", "lat": 39.71, "lng": -104.98, "sequence": 1 },
     { "stopId": "S2", "name": "Customer B", "address": "456 Oak Ave", "lat": 39.73, "lng": -104.95, "sequence": 2 }
   ]
   ```

3. Call `Web_display`:
   - `jobId`: the unique Job ID
   - `driverName`: driver's name
   - `stopsJson`: the formatted JSON array above

4. The tool returns a self-contained HTML string with:
   - Interactive Leaflet.js map with numbered stop markers
   - Popup on each marker: stop sequence, name, address, navigation link
   - Action buttons per stop: Mark Complete, Report Exception
   - Email-friendly stop list table below the map

5. Present the HTML to the user and offer to:
   - Deploy it to Cloudflare (use `web-display-deploy` skill)
   - Save it as a local `.html` file

---

## Notes

- One page per driver — never combine multiple drivers' stops on one page.
- The page is mobile-optimized; drivers can open it on any smartphone browser.
- Navigation links in the popup open the device's native maps app.
- After generating, the HTML should be passed directly to `Web_display_deploy` without modification.
