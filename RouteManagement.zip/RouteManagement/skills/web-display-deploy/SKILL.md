---
name: web-display-deploy
description: >
  This skill should be used when the user wants to "deploy a route page",
  "publish a route to the web", "share a route link with a driver",
  "deploy HTML to Cloudflare", "get a public URL for a route", or
  "make a route accessible online". Use after generating a route HTML
  page with the web-display skill.
metadata:
  version: "0.1.0"
---

## Purpose

Deploy a route HTML page to Cloudflare Pages and return a public shareable URL using `Web_display_deploy`.

**Do NOT deploy manually written HTML.** Only deploy HTML that was returned by `Web_display` — this ensures the correct interactive map format is used.

---

## Steps

1. Obtain the HTML content to deploy. This should be:
   - The direct output from `Web_display`, OR
   - An HTML string the user provides explicitly

2. Determine the Job ID for this deployment (e.g., `ROUTE-20260618-Alice`). If the user hasn't specified one, generate one from the route date and driver name.

3. Call `Web_display_deploy`:
   - `htmlContent`: the complete HTML string
   - `jobId`: unique job/project name (used as the Cloudflare project identifier)

4. The tool returns a public Cloudflare Pages URL. Store and display this URL.

5. Confirm the deployment:
   - Show the public URL
   - Confirm it's ready to share with the driver
   - Offer to include the URL in a Gmail draft (use `email-template` + Gmail draft)

---

## Notes

- Each `jobId` creates or updates a Cloudflare Pages project. Re-deploying with the same `jobId` overwrites the previous version.
- The URL is publicly accessible — no authentication required — suitable for sharing via email or SMS.
- If deployment fails, save the HTML locally as a `.html` file fallback so the driver still has access.
