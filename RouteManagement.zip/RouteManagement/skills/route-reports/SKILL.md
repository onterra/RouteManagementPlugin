---
name: route-reports
description: >
  This skill should be used when the user wants to "generate a route report",
  "get a status report for a route", "see stop statuses for a job",
  "download a delivery report", "check which stops were completed",
  "get a CSV of route results", or "report on route ROUTE-ID". Use to
  collect all stop statuses for a completed or in-progress route and
  produce a CSV report.
metadata:
  version: "0.1.0"
---

## Purpose

Collect all stop statuses for a route and generate a CSV report using `Reports`.

---

## Steps

1. Ask the user for the Route/Job ID to report on if not already provided (e.g., `ROUTE-20260618-Alice`).

2. Call `Reports`:
   - `routeId`: the Route/Job ID

3. The tool returns a CSV with stop-level status data. Parse and present a summary:

| Stop # | Customer | Address | Status | Notes |
|--------|----------|---------|--------|-------|
| 1 | ... | ... | Completed | ... |
| 2 | ... | ... | Exception | Driver: address locked |
| 3 | ... | ... | Pending | ... |

4. Summarize totals:
   - Total stops
   - Completed
   - Exceptions / incidents
   - Pending (not yet visited)

5. Offer to:
   - Save the CSV as a file
   - Flag exceptions for follow-up via `check-incidents`
   - Send a summary email to the dispatcher

---

## Notes

- Reports pull stop status data from KV storage — statuses are updated in real time as drivers mark stops complete or report exceptions on their route page.
- A route must have been created via `route-optimize` and deployed via `web-display-deploy` for stop statuses to be tracked.
- Route IDs follow the pattern used during `route-optimize` (e.g., `ROUTE-YYYYMMDD-DriverName`).
